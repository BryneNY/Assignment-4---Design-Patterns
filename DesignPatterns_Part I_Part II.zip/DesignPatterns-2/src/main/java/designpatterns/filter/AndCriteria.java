package designpatterns.filter;

import java.util.List;

/**
 * {@link Criteria} that keeps only persons who satisfy both of two criteria.
 *
 * @author Bryne
 * @version 1.0
 */
public class AndCriteria implements Criteria {

    /** The first criterion to apply. Stored so filters can be combined freely. */
    private final Criteria criteria;

    /** The second criterion, applied to the result of the first. */
    private final Criteria otherCriteria;

    /**
     * Creates a criterion that combines two others with logical AND.
     *
     * @param criteria      the first criterion
     * @param otherCriteria the second criterion
     */
    public AndCriteria(Criteria criteria, Criteria otherCriteria) {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    /**
     * Returns the persons who meet both criteria.
     *
     * @param persons the list to filter; it is not modified
     * @return a new list of persons matching both criteria
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> firstCriteriaPersons = criteria.meetCriteria(persons);
        return otherCriteria.meetCriteria(firstCriteriaPersons);
    }
}