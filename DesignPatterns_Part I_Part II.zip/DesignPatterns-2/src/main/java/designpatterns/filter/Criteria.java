package designpatterns.filter;

import java.util.List;

/**
 * Demonstrates the Filter (Criteria) design pattern: each implementation
 * filters a list of {@link Person} objects by one rule, and criteria can be
 * combined with {@link AndCriteria} and {@link OrCriteria}.
 *
 * @author Bryne
 * @version 1.0
 */
public interface Criteria {

    /**
     * Returns the persons that satisfy this criterion.
     *
     * @param persons the list to filter; it is not modified
     * @return a new list containing only the matching persons
     */
    List<Person> meetCriteria(List<Person> persons);
}
