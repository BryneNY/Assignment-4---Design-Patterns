package designpatterns.filter;

/**
 * A person to be filtered by {@link Criteria} objects.
 *
 * @author Bryne
 * @version 1.0
 */
public class Person {

    /** The person's name; used to identify the person in results. */
    private final String name;

    /** The person's gender ("Male" or "Female"); used by gender criteria. */
    private final String gender;

    /** The person's marital status (e.g. "Single"); used by marital criteria. */
    private final String maritalStatus;

    /**
     * Creates a person.
     *
     * @param name          the person's name
     * @param gender        the person's gender
     * @param maritalStatus the person's marital status
     */
    public Person(String name, String gender, String maritalStatus) {
        this.name = name;
        this.gender = gender;
        this.maritalStatus = maritalStatus;
    }

    /**
     * Returns the person's name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the person's gender.
     *
     * @return the gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * Returns the person's marital status.
     *
     * @return the marital status
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }
}
