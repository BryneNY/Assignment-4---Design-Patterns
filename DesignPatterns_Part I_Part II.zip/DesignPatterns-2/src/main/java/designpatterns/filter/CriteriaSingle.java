package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link Criteria} that keeps only persons who are single.
 *
 * @author Bryne
 * @version 1.0
 */
public class CriteriaSingle implements Criteria {

    /**
     * Returns the persons who are single.
     *
     * @param persons the list to filter; it is not modified
     * @return a new list containing only single persons
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> result = new ArrayList<>();
        for (Person person : persons) {
            if (person.getMaritalStatus().equalsIgnoreCase("SINGLE")) {
                result.add(person);
            }
        }
        return result;
    }
}
