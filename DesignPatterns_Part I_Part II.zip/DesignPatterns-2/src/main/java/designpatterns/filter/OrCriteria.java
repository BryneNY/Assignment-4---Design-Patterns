package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link Criteria} that keeps persons who satisfy at least one of two criteria.
 *
 * @author Bryne
 * @version 1.0
 */
public class OrCriteria implements Criteria {

    /** The first criterion to apply. Stored so filters can be combined freely. */
    private final Criteria criteria;

    /** The second criterion, whose matches are added to the first's. */
    private final Criteria otherCriteria;

    /**
     * Creates a criterion that combines two others with logical OR.
     *
     * @param criteria      the first criterion
     * @param otherCriteria the second criterion
     */
    public OrCriteria(Criteria criteria, Criteria otherCriteria) {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    /**
     * Returns the persons who meet either criterion, without duplicates.
     *
     * @param persons the list to filter; it is not modified
     * @return a new list of persons matching at least one criterion
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> result = new ArrayList<>(criteria.meetCriteria(persons));
        for (Person person : otherCriteria.meetCriteria(persons)) {
            if (!result.contains(person)) {
                result.add(person);
            }
        }
        return result;
    }
}
