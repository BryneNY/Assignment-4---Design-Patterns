package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link Criteria} that keeps only persons who are female.
 *
 * @author Bryne
 * @version 1.0
 */
public class CriteriaFemale implements Criteria {

    /**
     * Returns the persons who are female.
     *
     * @param persons the list to filter; it is not modified
     * @return a new list containing only female persons
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> result = new ArrayList<>();
        for (Person person : persons) {
            if (person.getGender().equalsIgnoreCase("FEMALE")) {
                result.add(person);
            }
        }
        return result;
    }
}
