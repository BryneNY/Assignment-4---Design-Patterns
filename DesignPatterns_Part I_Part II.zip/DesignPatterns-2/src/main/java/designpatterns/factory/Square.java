package designpatterns.factory;

/**
 * Concrete {@link Shape} representing a square.
 *
 * @author Bryne
 * @version 1.0
 */
public class Square implements Shape {

    /**
     * Draws the square.
     *
     * @return the message {@code "Inside Square::draw() method."}
     */
    @Override
    public String draw() {
        return "Inside Square::draw() method.";
    }
}
