package designpatterns.factory;

/**
 * Concrete {@link Shape} representing a circle.
 *
 * @author Bryne
 * @version 1.0
 */
public class Circle implements Shape {

    /**
     * Draws the circle.
     *
     * @return the message {@code "Inside Circle::draw() method."}
     */
    @Override
    public String draw() {
        return "Inside Circle::draw() method.";
    }
}
    
