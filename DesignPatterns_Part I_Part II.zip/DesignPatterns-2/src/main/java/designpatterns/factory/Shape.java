package designpatterns.factory;

/**
 * Common interface for all shapes produced by {@link ShapeFactory}.
 * Client code depends only on this interface, never on concrete classes.
 *
 * @author Bryne
 * @version 1.0
 */
public interface Shape {

    /**
     * Draws the shape.
     *
     * @return a message describing which shape was drawn
     */
    String draw();
}
