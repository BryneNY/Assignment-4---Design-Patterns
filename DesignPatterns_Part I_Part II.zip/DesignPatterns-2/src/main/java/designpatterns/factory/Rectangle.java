package designpatterns.factory;

/**
 * Concrete {@link Shape} representing a rectangle.
 *
 * @author Bryne
 * @version 1.0
 */
public class Rectangle implements Shape {

    /**
     * Draws the rectangle.
     *
     * @return the message {@code "Inside Rectangle::draw() method."}
     */
    @Override
    public String draw() {
        return "Inside Rectangle::draw() method.";
    }
}
