package designpatterns.factory;

/**
 * Demonstrates the Factory design pattern: creates {@link Shape} objects
 * without exposing the creation logic to the client. The client asks for a
 * shape by name and receives it through the common {@code Shape} interface.
 *
 * @author Bryne
 * @version 1.0
 */
public class ShapeFactory {

    /**
     * Creates a shape of the requested type. The comparison ignores case.
     *
     * @param shapeType the type of shape wanted: "CIRCLE", "RECTANGLE" or "SQUARE"
     * @return a new {@link Shape} of the requested type, or {@code null} if
     *         {@code shapeType} is {@code null} or not a known shape
     */
    public Shape getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }
        if (shapeType.equalsIgnoreCase("CIRCLE")) {
            return new Circle();
        } else if (shapeType.equalsIgnoreCase("RECTANGLE")) {
            return new Rectangle();
        } else if (shapeType.equalsIgnoreCase("SQUARE")) {
            return new Square();
        }
        return null;
    }
}
