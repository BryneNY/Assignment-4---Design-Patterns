package designpatterns.state;

/**
 * Concrete {@link State} representing the "start" state.
 *
 * @author Bryne
 * @version 1.0
 */
public class StartState implements State {

    /**
     * Puts the context into the start state.
     *
     * @param context the context to move into this state
     */
    @Override
    public void doAction(Context context) {
        context.setState(this);
    }

    /**
     * Returns a readable name for this state.
     *
     * @return the text {@code "Start State"}
     */
    @Override
    public String toString() {
        return "Start State";
    }
}
