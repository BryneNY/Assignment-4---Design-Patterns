package designpatterns.state;

/**
 * The object whose behaviour changes with its state. It does not contain
 * any state-specific logic itself; it simply holds the current {@link State}.
 *
 * @author Bryne
 * @version 1.0
 */
public class Context {

    /**
     * The current state. Starts as {@code null} because no state has been
     * entered yet; storing it as a field is what lets behavior change at
     * run time without conditional statements.
     */
    private State state;

    /**
     * Creates a context with no current state.
     */
    public Context() {
        state = null;
    }

    /**
     * Sets the current state.
     *
     * @param state the new current state
     */
    public void setState(State state) {
        this.state = state;
    }

    /**
     * Returns the current state.
     *
     * @return the current state, or {@code null} if none has been set
     */
    public State getState() {
        return state;
    }
}
