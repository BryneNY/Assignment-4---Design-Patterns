package designpatterns.state;

/**
 * Interface for every state in the State design pattern. Each concrete state
 * decides what happens when it is applied to a {@link Context}.
 *
 * @author Bryne
 * @version 1.0
 */
public interface State {

    /**
     * Performs this state's action on the given context, which includes
     * making this state the context's current state.
     *
     * @param context the context whose state is changing
     */
    void doAction(Context context);
}