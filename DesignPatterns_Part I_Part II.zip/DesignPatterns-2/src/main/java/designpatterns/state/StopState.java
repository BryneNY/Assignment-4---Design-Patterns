package designpatterns.state;

/**
 * Concrete {@link State} representing the "stop" state.
 *
 * @author Bryne
 * @version 1.0
 */
public class StopState implements State {

    /**
     * Puts the context into the stop state.
     *
     * @param context the context to move into this state
     */
    @Override
    public void doAction(Context context) {
        context.setState(this);
    }

    /**
     * Returns a readable name for this state.
     *
     * @return the text {@code "Stop State"}
     */
    @Override
    public String toString() {
        return "Stop State";
    }
}
