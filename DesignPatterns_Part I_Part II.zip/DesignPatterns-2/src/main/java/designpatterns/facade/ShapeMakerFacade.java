package designpatterns.facade;

import designpatterns.factory.Circle;
import designpatterns.factory.Rectangle;
import designpatterns.factory.Shape;
import designpatterns.factory.Square;

/**
 * Demonstrates the Facade design pattern: provides one simple interface that
 * hides the individual shape classes from the client. The client calls
 * {@code drawCircle()} instead of creating and managing a {@link Circle}
 * itself.
 *
 * @author Bryne
 * @version 1.0
 */
public class ShapeMakerFacade {

    /**
     * The circle hidden behind the facade. Held as a field so it is created
     * once and reused for every {@link #drawCircle()} call.
     */
    private final Shape circle;

    /** The rectangle hidden behind the facade, reused by {@link #drawRectangle()}. */
    private final Shape rectangle;

    /** The square hidden behind the facade, reused by {@link #drawSquare()}. */
    private final Shape square;

    /**
     * Creates the facade and the shapes it manages.
     */
    public ShapeMakerFacade() {
        circle = new Circle();
        rectangle = new Rectangle();
        square = new Square();
    }

    /**
     * Draws a circle.
     *
     * @return the message produced by drawing the circle
     */
    public String drawCircle() {
        return circle.draw();
    }

    /**
     * Draws a rectangle.
     *
     * @return the message produced by drawing the rectangle
     */
    public String drawRectangle() {
        return rectangle.draw();
    }

    /**
     * Draws a square.
     *
     * @return the message produced by drawing the square
     */
    public String drawSquare() {
        return square.draw();
    }
}