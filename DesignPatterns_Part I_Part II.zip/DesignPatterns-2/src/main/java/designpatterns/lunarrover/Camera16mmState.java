package designpatterns.lunarrover;

/**
 * Camera substate: the 16-mm camera is selected.
 *
 * @author Bryne
 * @version 1.0
 */
public class Camera16mmState extends CameraState {

    /**
     * Returns the name of this state.
     *
     * @return {@code "16-mm Camera"}
     */
    @Override
    public String getName() {
        return "16-mm Camera";
    }
}