package designpatterns.lunarrover;

/**
 * Movement substate: the rover is stationary. This is the initial state.
 *
 * @author Bryne
 * @version 1.0
 */
public class AtRestState extends MovementControlState {

    /**
     * Left pedal pressed once accelerates forward; held for more than
     * {@link LunarRover#MOVEMENT_HOLD_SECONDS} seconds accelerates backward.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        if (seconds > LunarRover.MOVEMENT_HOLD_SECONDS) {
            return moveTo(rover, new AcceleratingBackwardState());
        }
        return moveTo(rover, new AcceleratingForwardState());
    }

    /**
     * Switches to Camera and Drill Control, which starts in Idle. Allowed
     * only here because the rover is not moving.
     *
     * @param rover the rover whose state changes
     * @return a message describing the new state
     */
    @Override
    public String flipSwitch(LunarRover rover) {
        return moveTo(rover, new IdleState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "At Rest"}
     */
    @Override
    public String getName() {
        return "At Rest";
    }
}