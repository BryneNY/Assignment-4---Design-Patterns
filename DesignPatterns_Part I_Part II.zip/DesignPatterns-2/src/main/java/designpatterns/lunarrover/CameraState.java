package designpatterns.lunarrover;

/**
 * Shared behaviour of the two camera modes. A short left press takes a
 * picture; holding it for {@link LunarRover#TEMPORIZER_HOLD_SECONDS} seconds
 * or more activates the temporizer. Taking a picture and the temporizer are
 * short activities, after which the camera is ready again, so the state does
 * not change.
 *
 * @author Bryne
 * @version 1.0
 */
public abstract class CameraState extends CameraAndDrillControlState {

    /**
     * Takes a picture, or a delayed picture if the pedal was held long enough.
     *
     * @param rover   the rover, whose picture count increases
     * @param seconds how long the pedal was held
     * @return a message describing the picture taken
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        rover.recordPicture();
        if (seconds >= LunarRover.TEMPORIZER_HOLD_SECONDS) {
            return "Temporizer activated: delayed picture taken with the " + getName() + ".";
        }
        return "Picture taken with the " + getName() + ".";
    }
}
