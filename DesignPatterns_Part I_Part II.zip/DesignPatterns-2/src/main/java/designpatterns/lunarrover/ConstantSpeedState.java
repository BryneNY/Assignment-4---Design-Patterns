package designpatterns.lunarrover;

/**
 * Movement substate: the rover is moving forward at a constant speed.
 *
 * @author Bryne
 * @version 1.0
 */
public class ConstantSpeedState extends MovementControlState {

    /**
     * Left pedal accelerates forward again (assumption).
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new AcceleratingForwardState());
    }

    /**
     * Right pedal pressed once decelerates; holding it for more than
     * {@link LunarRover#MOVEMENT_HOLD_SECONDS} seconds keeps the constant speed.
     *
     * @param rover   the rover whose state may change
     * @param seconds how long the pedal was held
     * @return a message describing the result
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        if (seconds > LunarRover.MOVEMENT_HOLD_SECONDS) {
            return "Rover keeps a constant forward speed.";
        }
        return moveTo(rover, new DeceleratingState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Constant Speed"}
     */
    @Override
    public String getName() {
        return "Constant Speed";
    }
}
