package designpatterns.lunarrover;

/**
 * Composite state "Camera and Drill Control". Its substates are Idle, the
 * two camera states and the two drill states. Behaviour shared by all of
 * them lives here.
 *
 * @author Bryne
 * @version 1.0
 */
public abstract class CameraAndDrillControlState extends AbstractRoverState {

    /**
     * Right pedal returns to Idle from any device mode. Leaving the drill
     * this way also stops it.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new IdleState());
    }

    /**
     * Switches back to Movement Control, which starts At Rest. Any active
     * device is stopped because its state is left.
     *
     * @param rover the rover whose state changes
     * @return a message describing the new state
     */
    @Override
    public String flipSwitch(LunarRover rover) {
        return moveTo(rover, new AtRestState());
    }
}
