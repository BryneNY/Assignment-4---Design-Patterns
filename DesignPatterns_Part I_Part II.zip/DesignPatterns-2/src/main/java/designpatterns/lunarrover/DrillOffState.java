package designpatterns.lunarrover;

/**
 * Drill substate: the drill is selected but switched off.
 *
 * @author Bryne
 * @version 1.0
 */
public class DrillOffState extends CameraAndDrillControlState {

    /**
     * Left pedal switches the drill on.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new DrillOnState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Drill Off"}
     */
    @Override
    public String getName() {
        return "Drill Off";
    }
}
