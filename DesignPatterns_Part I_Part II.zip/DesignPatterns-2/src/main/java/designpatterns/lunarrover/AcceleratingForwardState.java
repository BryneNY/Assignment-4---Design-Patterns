package designpatterns.lunarrover;

/**
 * Movement substate: the rover is speeding up while moving forward.
 *
 * @author Bryne
 * @version 1.0
 */
public class AcceleratingForwardState extends MovementControlState {

    /**
     * Left pedal keeps the rover accelerating forward.
     *
     * @param rover   the rover (state unchanged)
     * @param seconds how long the pedal was held
     * @return a message saying the rover keeps accelerating
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return "Rover keeps accelerating forward.";
    }

    /**
     * Right pedal pressed once decelerates; held for more than
     * {@link LunarRover#MOVEMENT_HOLD_SECONDS} seconds holds a constant speed.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        if (seconds > LunarRover.MOVEMENT_HOLD_SECONDS) {
            return moveTo(rover, new ConstantSpeedState());
        }
        return moveTo(rover, new DeceleratingState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Accelerating Forward"}
     */
    @Override
    public String getName() {
        return "Accelerating Forward";
    }
}
