package designpatterns.lunarrover;

/**
 * Movement substate: the rover is slowing down while moving forward.
 *
 * @author Bryne
 * @version 1.0
 */
public class DeceleratingState extends MovementControlState {

    /**
     * Left pedal accelerates forward again (assumption).
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new AcceleratingForwardState());
    }

    /**
     * Right pedal pressed once brings the rover to rest (assumption: a second
     * press finishes braking); held for more than
     * {@link LunarRover#MOVEMENT_HOLD_SECONDS} seconds holds a constant speed.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        if (seconds > LunarRover.MOVEMENT_HOLD_SECONDS) {
            return moveTo(rover, new ConstantSpeedState());
        }
        return moveTo(rover, new AtRestState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Decelerating"}
     */
    @Override
    public String getName() {
        return "Decelerating";
    }
}
