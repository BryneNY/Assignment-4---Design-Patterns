package designpatterns.lunarrover;

/**
 * Composite state "Movement Control". Its substates are At Rest,
 * Accelerating Forward, Constant Speed, Decelerating and Accelerating
 * Backward. Behaviour shared by all of them lives here.
 *
 * @author Bryne
 * @version 1.0
 */
public abstract class MovementControlState extends AbstractRoverState {

    /**
     * Refuses to switch modes, because the pedals cannot be handed over to
     * the cameras and drill while the rover is moving. {@link AtRestState}
     * overrides this to allow the switch.
     *
     * @param rover the rover (unchanged)
     * @return a message explaining why the switch was refused
     */
    @Override
    public String flipSwitch(LunarRover rover) {
        return "Cannot switch modes while the rover is moving (" + getName() + ").";
    }
}