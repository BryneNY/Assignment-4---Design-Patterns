package designpatterns.lunarrover;

/**
 * Sample run of the Lunar Rover state machine. Drives the rover, switches
 * modes, uses both cameras and the drill, printing each input and result.
 * Every change happens through pedal or switch inputs only.
 *
 * @author Bryne
 * @version 1.0
 */
public class LunarRoverDemo {

    /**
     * Private constructor; this class only provides {@link #main(String[])}.
     */
    private LunarRoverDemo() {
    }

    /**
     * Runs the demonstration.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        LunarRover rover = new LunarRover();
        System.out.println("Start:                    " + rover.getState());
        System.out.println("--- Movement Control ---");
        System.out.println("Hold left pedal 4s     -> " + rover.holdLeftPedal(4));
        System.out.println("Flip switch            -> " + rover.flipSwitch());
        System.out.println("Press right pedal      -> " + rover.pressRightPedal());
        System.out.println("Press left pedal       -> " + rover.pressLeftPedal());
        System.out.println("Hold right pedal 4s    -> " + rover.holdRightPedal(4));
        System.out.println("Press right pedal      -> " + rover.pressRightPedal());
        System.out.println("Press right pedal      -> " + rover.pressRightPedal());
        System.out.println("--- Camera and Drill Control ---");
        System.out.println("Flip switch            -> " + rover.flipSwitch());
        System.out.println("Hold left pedal 5s     -> " + rover.holdLeftPedal(5));
        System.out.println("Press left pedal       -> " + rover.pressLeftPedal());
        System.out.println("Hold left pedal 5s     -> " + rover.holdLeftPedal(5));
        System.out.println("Press right pedal      -> " + rover.pressRightPedal());
        System.out.println("Hold left pedal 10s    -> " + rover.holdLeftPedal(10));
        System.out.println("Press left pedal       -> " + rover.pressLeftPedal());
        System.out.println("Press right pedal      -> " + rover.pressRightPedal());
        System.out.println("Double press left      -> " + rover.doublePressLeftPedal());
        System.out.println("Press left pedal       -> " + rover.pressLeftPedal());
        System.out.println("Press left pedal       -> " + rover.pressLeftPedal());
        System.out.println("Flip switch            -> " + rover.flipSwitch());
        System.out.println("Pictures taken: " + rover.getPicturesTaken());
    }
}
