package designpatterns.lunarrover;

/**
 * Device substate: no camera or drill is selected. Devices can only be
 * selected from here, which keeps selection separate from camera controls.
 *
 * @author Bryne
 * @version 1.0
 */
public class IdleState extends CameraAndDrillControlState {

    /**
     * Left pedal held for {@link LunarRover#CAMERA_16MM_HOLD_SECONDS} seconds
     * or more selects the 16-mm camera; held for
     * {@link LunarRover#COLOR_CAMERA_HOLD_SECONDS} seconds or more selects the
     * color camera. Shorter presses do nothing.
     *
     * @param rover   the rover whose state may change
     * @param seconds how long the pedal was held
     * @return a message describing the result
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        if (seconds >= LunarRover.CAMERA_16MM_HOLD_SECONDS) {
            return moveTo(rover, new Camera16mmState());
        }
        if (seconds >= LunarRover.COLOR_CAMERA_HOLD_SECONDS) {
            return moveTo(rover, new ColorCameraState());
        }
        return ignored("Short left pedal press");
    }

    /**
     * Double press of the left pedal selects the drill, which starts off.
     *
     * @param rover the rover whose state changes
     * @return a message describing the new state
     */
    @Override
    public String doublePressLeftPedal(LunarRover rover) {
        return moveTo(rover, new DrillOffState());
    }

    /**
     * Right pedal while already idle has no effect.
     *
     * @param rover   the rover (unchanged)
     * @param seconds how long the pedal was held
     * @return a message saying the input had no effect
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        return ignored("Right pedal");
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Idle"}
     */
    @Override
    public String getName() {
        return "Idle";
    }
}
