package designpatterns.lunarrover;

/**
 * A state of the Lunar Rover in the State design pattern. The rover has only
 * two pedals and a mode switch, so every state must say what each of those
 * inputs does. Each concrete state decides its own behaviour and next state,
 * replacing the if/else chains of the original design.
 *
 * @author Bryne
 * @version 1.0
 */
public interface LunarRoverState {

    /**
     * Handles the left pedal being pressed (0 seconds) or held.
     *
     * @param rover   the rover whose state may change
     * @param seconds how long the pedal was held; 0 for a short press
     * @return a message describing what happened
     */
    String leftPedal(LunarRover rover, double seconds);

    /**
     * Handles the right pedal being pressed (0 seconds) or held.
     *
     * @param rover   the rover whose state may change
     * @param seconds how long the pedal was held; 0 for a short press
     * @return a message describing what happened
     */
    String rightPedal(LunarRover rover, double seconds);

    /**
     * Handles the left pedal being pressed twice in quick succession.
     *
     * @param rover the rover whose state may change
     * @return a message describing what happened
     */
    String doublePressLeftPedal(LunarRover rover);

    /**
     * Handles the mode switch being flipped between Movement Control and
     * Camera and Drill Control.
     *
     * @param rover the rover whose state may change
     * @return a message describing what happened
     */
    String flipSwitch(LunarRover rover);

    /**
     * Returns the human-readable name of this state.
     *
     * @return the state's name, e.g. {@code "At Rest"}
     */
    String getName();
}