package designpatterns.lunarrover;

/**
 * Drill substate: the drill is selected and running.
 *
 * @author Bryne
 * @version 1.0
 */
public class DrillOnState extends CameraAndDrillControlState {

    /**
     * Left pedal switches the drill off.
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new DrillOffState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Drill On"}
     */
    @Override
    public String getName() {
        return "Drill On";
    }
}