package designpatterns.lunarrover;

/**
 * Camera substate: the color television camera is selected.
 *
 * @author Bryne
 * @version 1.0
 */
public class ColorCameraState extends CameraState {

    /**
     * Returns the name of this state.
     *
     * @return {@code "Color Camera"}
     */
    @Override
    public String getName() {
        return "Color Camera";
    }
}