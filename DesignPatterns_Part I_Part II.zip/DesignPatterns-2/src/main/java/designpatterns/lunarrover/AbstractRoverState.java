package designpatterns.lunarrover;

/**
 * Base class for all Lunar Rover states. By default every input is ignored,
 * so each concrete state only overrides the inputs that matter to it. This
 * keeps "nothing happens" behaviour in one place instead of repeating it.
 *
 * @author Bryne
 * @version 1.0
 */
public abstract class AbstractRoverState implements LunarRoverState {

    /**
     * Ignores the left pedal unless a subclass overrides this.
     *
     * @param rover   the rover (unchanged)
     * @param seconds how long the pedal was held
     * @return a message saying the input had no effect
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return ignored("Left pedal");
    }

    /**
     * Ignores the right pedal unless a subclass overrides this.
     *
     * @param rover   the rover (unchanged)
     * @param seconds how long the pedal was held
     * @return a message saying the input had no effect
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        return ignored("Right pedal");
    }

    /**
     * Ignores a double press of the left pedal unless a subclass overrides this.
     *
     * @param rover the rover (unchanged)
     * @return a message saying the input had no effect
     */
    @Override
    public String doublePressLeftPedal(LunarRover rover) {
        return ignored("Double press of left pedal");
    }

    /**
     * Ignores the mode switch unless a subclass overrides this.
     *
     * @param rover the rover (unchanged)
     * @return a message saying the input had no effect
     */
    @Override
    public String flipSwitch(LunarRover rover) {
        return ignored("Mode switch");
    }

    /**
     * Builds the message used when an input has no effect in this state.
     *
     * @param input the name of the ignored input
     * @return a message such as {@code "Right pedal has no effect in At Rest."}
     */
    protected String ignored(String input) {
        return input + " has no effect in " + getName() + ".";
    }

    /**
     * Moves the rover into another state and describes the transition.
     *
     * @param rover the rover to update
     * @param next  the state to enter
     * @return the message {@code "Rover is now: <state name>"}
     */
    protected String moveTo(LunarRover rover, LunarRoverState next) {
        rover.setState(next);
        return "Rover is now: " + next.getName();
    }

    /**
     * Returns the state's name, for readable printing.
     *
     * @return the same value as {@link #getName()}
     */
    @Override
    public String toString() {
        return getName();
    }
}