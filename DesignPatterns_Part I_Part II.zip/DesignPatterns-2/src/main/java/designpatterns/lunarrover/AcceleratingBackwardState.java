package designpatterns.lunarrover;

/**
 * Movement substate: the rover is moving backward.
 *
 * @author Bryne
 * @version 1.0
 */
public class AcceleratingBackwardState extends MovementControlState {

    /**
     * Left pedal keeps the rover moving backward.
     *
     * @param rover   the rover (state unchanged)
     * @param seconds how long the pedal was held
     * @return a message saying the rover keeps reversing
     */
    @Override
    public String leftPedal(LunarRover rover, double seconds) {
        return "Rover keeps accelerating backward.";
    }

    /**
     * Right pedal brakes the rover to rest (assumption).
     *
     * @param rover   the rover whose state changes
     * @param seconds how long the pedal was held
     * @return a message describing the new state
     */
    @Override
    public String rightPedal(LunarRover rover, double seconds) {
        return moveTo(rover, new AtRestState());
    }

    /**
     * Returns the name of this state.
     *
     * @return {@code "Accelerating Backward"}
     */
    @Override
    public String getName() {
        return "Accelerating Backward";
    }
}
