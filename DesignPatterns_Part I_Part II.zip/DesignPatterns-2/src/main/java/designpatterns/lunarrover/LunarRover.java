package designpatterns.lunarrover;

/**
 * The Lunar Rover: the context class of the State design pattern. It holds
 * its current {@link LunarRoverState} and hands every pedal and switch input
 * to it. The state objects perform the transitions, so this class contains
 * no if/else logic about states.
 *
 * @author Bryne
 * @version 1.0
 */
public class LunarRover {

    /**
     * Seconds a pedal must be held (strictly more than this) for the
     * "held" movement behaviours: reversing and constant speed. Defined
     * once so the rule is consistent across states.
     */
    public static final double MOVEMENT_HOLD_SECONDS = 3;

    /** Seconds the left pedal must be held in Idle to select the color camera. */
    public static final double COLOR_CAMERA_HOLD_SECONDS = 5;

    /** Seconds the left pedal must be held in Idle to select the 16-mm camera. */
    public static final double CAMERA_16MM_HOLD_SECONDS = 10;

    /** Seconds the left pedal must be held in a camera mode to use the temporizer. */
    public static final double TEMPORIZER_HOLD_SECONDS = 5;

    /**
     * The current state. All behaviour is delegated to it; replacing it is
     * how the rover changes behaviour at run time.
     */
    private LunarRoverState state;

    /**
     * Number of pictures taken by either camera. Kept so that taking a
     * picture, which does not change state, can still be observed and tested.
     */
    private int picturesTaken;

    /**
     * Creates a rover in Movement Control, at rest, with no pictures taken.
     */
    public LunarRover() {
        state = new AtRestState();
        picturesTaken = 0;
    }

    /**
     * Presses the left pedal once.
     *
     * @return a message describing what happened
     */
    public String pressLeftPedal() {
        return state.leftPedal(this, 0);
    }

    /**
     * Holds the left pedal for the given number of seconds.
     *
     * @param seconds how long the pedal is held; must not be negative
     * @return a message describing what happened
     * @throws IllegalArgumentException if {@code seconds} is negative
     */
    public String holdLeftPedal(double seconds) {
        validateSeconds(seconds);
        return state.leftPedal(this, seconds);
    }

    /**
     * Presses the left pedal twice in quick succession.
     *
     * @return a message describing what happened
     */
    public String doublePressLeftPedal() {
        return state.doublePressLeftPedal(this);
    }

    /**
     * Presses the right pedal once.
     *
     * @return a message describing what happened
     */
    public String pressRightPedal() {
        return state.rightPedal(this, 0);
    }

    /**
     * Holds the right pedal for the given number of seconds.
     *
     * @param seconds how long the pedal is held; must not be negative
     * @return a message describing what happened
     * @throws IllegalArgumentException if {@code seconds} is negative
     */
    public String holdRightPedal(double seconds) {
        validateSeconds(seconds);
        return state.rightPedal(this, seconds);
    }

    /**
     * Flips the switch between Movement Control and Camera and Drill Control.
     *
     * @return a message describing what happened
     */
    public String flipSwitch() {
        return state.flipSwitch(this);
    }

    /**
     * Returns the rover's current state.
     *
     * @return the current state; never {@code null}
     */
    public LunarRoverState getState() {
        return state;
    }

    /**
     * Returns how many pictures have been taken.
     *
     * @return the number of pictures taken by either camera
     */
    public int getPicturesTaken() {
        return picturesTaken;
    }

    /**
     * Changes the current state. Package-private so that only state classes,
     * which share this package, can trigger transitions.
     *
     * @param state the new state; must not be {@code null}
     * @throws IllegalArgumentException if {@code state} is {@code null}
     */
    void setState(LunarRoverState state) {
        if (state == null) {
            throw new IllegalArgumentException("State must not be null");
        }
        this.state = state;
    }

    /**
     * Records that a camera took a picture. Package-private so only camera
     * states can call it.
     */
    void recordPicture() {
        picturesTaken++;
    }

    /**
     * Checks that a hold duration is valid.
     *
     * @param seconds the duration to check
     * @throws IllegalArgumentException if {@code seconds} is negative
     */
    private void validateSeconds(double seconds) {
        if (seconds < 0) {
            throw new IllegalArgumentException("Seconds must not be negative: " + seconds);
        }
    }
}