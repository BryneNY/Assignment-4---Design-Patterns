package designpatterns.singleton;

/**
 * Demonstrates the Singleton design pattern: a class that allows exactly one
 * instance of itself to exist and provides a global access point to it.
 *
 * @author Bryne
 * @version 1.0
 */
public class SingleObject {

    /**
     * The one and only instance of this class. It is static so it belongs to
     * the class rather than to any object, and final so it can never be
     * replaced. Eager initialization is simple and thread-safe.
     */
    private static final SingleObject INSTANCE = new SingleObject();

    /**
     * Private constructor. Prevents other classes from calling
     * {@code new SingleObject()}, guaranteeing only one instance exists.
     */
    private SingleObject() {
    }

    /**
     * Returns the single shared instance of this class.
     *
     * @return the unique {@code SingleObject} instance; never {@code null}
     */
    public static SingleObject getInstance() {
        return INSTANCE;
    }

    /**
     * Returns a greeting message, showing that the instance is usable.
     *
     * @return the message {@code "Hello World!"}
     */
    public String showMessage() {
        return "Hello World!";
    }
}
