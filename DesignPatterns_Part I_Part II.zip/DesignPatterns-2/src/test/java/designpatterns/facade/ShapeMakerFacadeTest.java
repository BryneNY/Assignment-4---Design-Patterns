package designpatterns.facade;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the {@link ShapeMakerFacade} class.
 *
 * @author Bryne
 * @version 1.0
 */
public class ShapeMakerFacadeTest {

    /** Facade under test; recreated before each test. */
    private ShapeMakerFacade shapeMakerFacade;

    /** Creates a fresh facade before each test. */
    @BeforeEach
    public void setUp() {
        shapeMakerFacade = new ShapeMakerFacade();
    }

    /** Verifies that the facade draws a circle. */
    @Test
    public void testDrawCircle() {
        assertEquals("Inside Circle::draw() method.", shapeMakerFacade.drawCircle());
    }

    /** Verifies that the facade draws a rectangle. */
    @Test
    public void testDrawRectangle() {
        assertEquals("Inside Rectangle::draw() method.", shapeMakerFacade.drawRectangle());
    }

    /** Verifies that the facade draws a square. */
    @Test
    public void testDrawSquare() {
        assertEquals("Inside Square::draw() method.", shapeMakerFacade.drawSquare());
    }

    /** Verifies that the facade gives the same result when called repeatedly. */
    @Test
    public void testDrawCircleRepeatedly() {
        assertEquals(shapeMakerFacade.drawCircle(), shapeMakerFacade.drawCircle());
    }
}