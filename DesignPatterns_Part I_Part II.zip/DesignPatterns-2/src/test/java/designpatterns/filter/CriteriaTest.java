package designpatterns.filter;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the Filter pattern classes.
 *
 * @author Bryne
 * @version 1.0
 */
public class CriteriaTest {

    /** Sample people shared by all tests; rebuilt before each test. */
    private List<Person> persons;

    /** Builds the sample list of people before each test. */
    @BeforeEach
    public void setUp() {
        persons = new ArrayList<>();
        persons.add(new Person("Robert", "Male", "Single"));
        persons.add(new Person("John", "Male", "Married"));
        persons.add(new Person("Laura", "Female", "Married"));
        persons.add(new Person("Diana", "Female", "Single"));
        persons.add(new Person("Mike", "Male", "Single"));
        persons.add(new Person("Bobby", "Male", "Single"));
    }

    /**
     * Collects the names of the given persons, to make assertions readable.
     *
     * @param list the persons
     * @return their names, in the same order
     */
    private List<String> names(List<Person> list) {
        List<String> result = new ArrayList<>();
        for (Person person : list) {
            result.add(person.getName());
        }
        return result;
    }

    /** Verifies that CriteriaMale keeps only males. */
    @Test
    public void testCriteriaMale() {
        assertEquals(List.of("Robert", "John", "Mike", "Bobby"),
                names(new CriteriaMale().meetCriteria(persons)));
    }

    /** Verifies that CriteriaFemale keeps only females. */
    @Test
    public void testCriteriaFemale() {
        assertEquals(List.of("Laura", "Diana"),
                names(new CriteriaFemale().meetCriteria(persons)));
    }

    /** Verifies that CriteriaSingle keeps only single people. */
    @Test
    public void testCriteriaSingle() {
        assertEquals(List.of("Robert", "Diana", "Mike", "Bobby"),
                names(new CriteriaSingle().meetCriteria(persons)));
    }

    /** Verifies that AndCriteria keeps people matching both criteria. */
    @Test
    public void testAndCriteria() {
        Criteria singleMale = new AndCriteria(new CriteriaSingle(), new CriteriaMale());
        assertEquals(List.of("Robert", "Mike", "Bobby"), names(singleMale.meetCriteria(persons)));
    }

    /** Verifies that OrCriteria keeps people matching either criterion, once each. */
    @Test
    public void testOrCriteria() {
        Criteria singleOrFemale = new OrCriteria(new CriteriaSingle(), new CriteriaFemale());
        assertEquals(List.of("Robert", "Diana", "Mike", "Bobby", "Laura"),
                names(singleOrFemale.meetCriteria(persons)));
    }

    /** Verifies that filtering an empty list returns an empty list. */
    @Test
    public void testCriteriaEmptyList() {
        assertTrue(new CriteriaMale().meetCriteria(new ArrayList<>()).isEmpty());
    }
}