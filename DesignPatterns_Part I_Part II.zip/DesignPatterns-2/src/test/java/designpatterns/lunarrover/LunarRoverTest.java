package designpatterns.lunarrover;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the State-pattern redesign of the Lunar Rover.
 *
 * @author Bryne
 * @version 1.0
 */
public class LunarRoverTest {

    /** Rover under test; a new one (at rest) is created before each test. */
    private LunarRover rover;

    /** Creates a fresh rover before each test. */
    @BeforeEach
    public void setUp() {
        rover = new LunarRover();
    }

    /** Verifies that a new rover starts in Movement Control, at rest. */
    @Test
    public void testInitialStateIsAtRest() {
        assertInstanceOf(AtRestState.class, rover.getState());
        assertInstanceOf(MovementControlState.class, rover.getState());
        assertEquals(0, rover.getPicturesTaken());
    }

    /** Verifies that pressing the left pedal at rest accelerates forward. */
    @Test
    public void testPressLeftPedalAtRestAcceleratesForward() {
        assertEquals("Rover is now: Accelerating Forward", rover.pressLeftPedal());
        assertInstanceOf(AcceleratingForwardState.class, rover.getState());
    }

    /** Verifies that holding the left pedal more than 3 seconds at rest accelerates backward. */
    @Test
    public void testHoldLeftPedalAtRestAcceleratesBackward() {
        rover.holdLeftPedal(4);
        assertInstanceOf(AcceleratingBackwardState.class, rover.getState());
    }

    /** Verifies that exactly 3 seconds is not "more than 3", so it counts as a press. */
    @Test
    public void testHoldLeftPedalThreeSecondsAcceleratesForward() {
        rover.holdLeftPedal(3);
        assertInstanceOf(AcceleratingForwardState.class, rover.getState());
    }

    /** Verifies that pressing the right pedal while accelerating forward decelerates. */
    @Test
    public void testPressRightPedalWhileAcceleratingDecelerates() {
        rover.pressLeftPedal();
        rover.pressRightPedal();
        assertInstanceOf(DeceleratingState.class, rover.getState());
    }

    /** Verifies that holding the right pedal more than 3 seconds reaches constant speed. */
    @Test
    public void testHoldRightPedalWhileAcceleratingReachesConstantSpeed() {
        rover.pressLeftPedal();
        rover.holdRightPedal(4);
        assertInstanceOf(ConstantSpeedState.class, rover.getState());
    }

    /** Verifies that pressing the right pedal at constant speed decelerates. */
    @Test
    public void testPressRightPedalAtConstantSpeedDecelerates() {
        rover.pressLeftPedal();
        rover.holdRightPedal(4);
        rover.pressRightPedal();
        assertInstanceOf(DeceleratingState.class, rover.getState());
    }

    /** Verifies that pressing the right pedal while decelerating brings the rover to rest. */
    @Test
    public void testPressRightPedalWhileDeceleratingStops() {
        rover.pressLeftPedal();
        rover.pressRightPedal();
        rover.pressRightPedal();
        assertInstanceOf(AtRestState.class, rover.getState());
    }

    /** Verifies that pressing the right pedal while reversing brings the rover to rest. */
    @Test
    public void testPressRightPedalWhileReversingStops() {
        rover.holdLeftPedal(4);
        rover.pressRightPedal();
        assertInstanceOf(AtRestState.class, rover.getState());
    }

    /** Verifies that the mode switch is refused while the rover is moving. */
    @Test
    public void testFlipSwitchWhileMovingIsRefused() {
        rover.pressLeftPedal();
        String message = rover.flipSwitch();
        assertTrue(message.startsWith("Cannot switch modes"));
        assertInstanceOf(AcceleratingForwardState.class, rover.getState());
    }

    /** Verifies that flipping the switch at rest enters Camera and Drill Control in Idle. */
    @Test
    public void testFlipSwitchAtRestEntersIdle() {
        rover.flipSwitch();
        assertInstanceOf(IdleState.class, rover.getState());
        assertInstanceOf(CameraAndDrillControlState.class, rover.getState());
    }

    /** Verifies that holding the left pedal 5 seconds in Idle selects the color camera. */
    @Test
    public void testHoldLeftPedalFiveSecondsSelectsColorCamera() {
        rover.flipSwitch();
        rover.holdLeftPedal(5);
        assertInstanceOf(ColorCameraState.class, rover.getState());
    }

    /** Verifies that holding the left pedal 10 seconds in Idle selects the 16-mm camera. */
    @Test
    public void testHoldLeftPedalTenSecondsSelects16mmCamera() {
        rover.flipSwitch();
        rover.holdLeftPedal(10);
        assertInstanceOf(Camera16mmState.class, rover.getState());
    }

    /** Verifies that a short left press in Idle selects nothing. */
    @Test
    public void testPressLeftPedalInIdleHasNoEffect() {
        rover.flipSwitch();
        rover.pressLeftPedal();
        assertInstanceOf(IdleState.class, rover.getState());
    }

    /** Verifies that a double press of the left pedal in Idle selects the drill, switched off. */
    @Test
    public void testDoublePressLeftPedalSelectsDrill() {
        rover.flipSwitch();
        rover.doublePressLeftPedal();
        assertInstanceOf(DrillOffState.class, rover.getState());
    }

    /** Verifies that a left press in a camera mode takes a picture without changing state. */
    @Test
    public void testPressLeftPedalInCameraTakesPicture() {
        rover.flipSwitch();
        rover.holdLeftPedal(5);
        assertEquals("Picture taken with the Color Camera.", rover.pressLeftPedal());
        assertEquals(1, rover.getPicturesTaken());
        assertInstanceOf(ColorCameraState.class, rover.getState());
    }

    /** Verifies that holding the left pedal 5 seconds in a camera mode uses the temporizer. */
    @Test
    public void testHoldLeftPedalInCameraActivatesTemporizer() {
        rover.flipSwitch();
        rover.holdLeftPedal(10);
        String message = rover.holdLeftPedal(5);
        assertTrue(message.startsWith("Temporizer activated"));
        assertEquals(1, rover.getPicturesTaken());
        assertInstanceOf(Camera16mmState.class, rover.getState());
    }

    /** Verifies that the left pedal switches the drill on and off. */
    @Test
    public void testLeftPedalTogglesDrill() {
        rover.flipSwitch();
        rover.doublePressLeftPedal();
        rover.pressLeftPedal();
        assertInstanceOf(DrillOnState.class, rover.getState());
        rover.pressLeftPedal();
        assertInstanceOf(DrillOffState.class, rover.getState());
    }

    /** Verifies that the right pedal returns to Idle from a camera mode and from the drill. */
    @Test
    public void testPressRightPedalReturnsToIdle() {
        rover.flipSwitch();
        rover.holdLeftPedal(5);
        rover.pressRightPedal();
        assertInstanceOf(IdleState.class, rover.getState());
        rover.doublePressLeftPedal();
        rover.pressLeftPedal();
        rover.pressRightPedal();
        assertInstanceOf(IdleState.class, rover.getState());
    }

    /** Verifies that flipping the switch in Camera and Drill Control returns to rest. */
    @Test
    public void testFlipSwitchFromDeviceModeReturnsToAtRest() {
        rover.flipSwitch();
        rover.doublePressLeftPedal();
        rover.pressLeftPedal();
        rover.flipSwitch();
        assertInstanceOf(AtRestState.class, rover.getState());
    }

    /** Verifies that a negative hold time is rejected and the state is unchanged. */
    @Test
    public void testHoldPedalNegativeSecondsThrows() {
        assertThrows(IllegalArgumentException.class, () -> rover.holdLeftPedal(-1));
        assertThrows(IllegalArgumentException.class, () -> rover.holdRightPedal(-1));
        assertInstanceOf(AtRestState.class, rover.getState());
    }
}