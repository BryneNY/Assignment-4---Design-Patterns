package designpatterns.state;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the State pattern classes {@link Context},
 * {@link StartState} and {@link StopState}.
 *
 * @author Bryne
 * @version 1.0
 */
public class ContextTest {

    /** Context under test; recreated before each test. */
    private Context context;

    /** Creates a fresh context before each test. */
    @BeforeEach
    public void setUp() {
        context = new Context();
    }

    /** Verifies that a new context has no state. */
    @Test
    public void testInitialStateIsNull() {
        assertNull(context.getState());
    }

    /** Verifies that applying a StartState moves the context into it. */
    @Test
    public void testStartState() {
        StartState startState = new StartState();
        startState.doAction(context);
        assertSame(startState, context.getState());
        assertEquals("Start State", context.getState().toString());
    }

    /** Verifies that applying a StopState moves the context into it. */
    @Test
    public void testStopState() {
        StopState stopState = new StopState();
        stopState.doAction(context);
        assertSame(stopState, context.getState());
        assertEquals("Stop State", context.getState().toString());
    }

    /** Verifies that the context changes state from start to stop. */
    @Test
    public void testTransitionFromStartToStop() {
        new StartState().doAction(context);
        assertInstanceOf(StartState.class, context.getState());
        new StopState().doAction(context);
        assertInstanceOf(StopState.class, context.getState());
    }
}