package designpatterns.factory;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for {@link ShapeFactory}.
 *
 * @author Bryne
 * @version 1.0
 */
public class ShapeFactoryTest {

    /** Factory under test; recreated before each test so tests stay independent. */
    private ShapeFactory shapeFactory;

    /** Creates a fresh factory before each test. */
    @BeforeEach
    public void setUp() {
        shapeFactory = new ShapeFactory();
    }

    /** Verifies that requesting "CIRCLE" returns a working Circle. */
    @Test
    public void testGetShapeCircle() {
        Shape shape = shapeFactory.getShape("CIRCLE");
        assertInstanceOf(Circle.class, shape);
        assertEquals("Inside Circle::draw() method.", shape.draw());
    }

    /** Verifies that requesting "RECTANGLE" returns a working Rectangle. */
    @Test
    public void testGetShapeRectangle() {
        Shape shape = shapeFactory.getShape("RECTANGLE");
        assertInstanceOf(Rectangle.class, shape);
        assertEquals("Inside Rectangle::draw() method.", shape.draw());
    }

    /** Verifies that requesting "SQUARE" returns a working Square. */
    @Test
    public void testGetShapeSquare() {
        Shape shape = shapeFactory.getShape("SQUARE");
        assertInstanceOf(Square.class, shape);
        assertEquals("Inside Square::draw() method.", shape.draw());
    }

    /** Verifies that the shape name is matched regardless of letter case. */
    @Test
    public void testGetShapeIgnoresCase() {
        assertInstanceOf(Circle.class, shapeFactory.getShape("circle"));
    }

    /** Verifies that unknown or null shape names return null. */
    @Test
    public void testGetShapeInvalidType() {
        assertNull(shapeFactory.getShape("TRIANGLE"));
        assertNull(shapeFactory.getShape(null));
    }

    /** Verifies that the factory creates a new object on each request. */
    @Test
    public void testGetShapeReturnsNewObjects() {
        assertNotSame(shapeFactory.getShape("SQUARE"), shapeFactory.getShape("SQUARE"));
    }
}