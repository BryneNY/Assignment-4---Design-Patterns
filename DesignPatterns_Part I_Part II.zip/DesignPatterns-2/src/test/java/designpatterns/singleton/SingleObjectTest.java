package designpatterns.singleton;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.jupiter.api.Test;

/**
 * JUnit tests for {@link SingleObject}.
 *
 * @author Bryne
 * @version 1.0
 */
public class SingleObjectTest {

    /**
     * Verifies that only a single object can be created: repeated calls to
     * getInstance() return the same object, and the constructor is private.
     *
     * @throws NoSuchMethodException if the no-argument constructor is missing
     */
    @Test
    public void testGetInstance() throws NoSuchMethodException {
        SingleObject first = SingleObject.getInstance();
        SingleObject second = SingleObject.getInstance();

        assertNotNull(first);
        assertSame(first, second, "getInstance() must always return the same object");

        Constructor<SingleObject> constructor = SingleObject.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()),
                "Constructor must be private so no other instance can be created");

        assertEquals("Hello World!", first.showMessage());
    }
}